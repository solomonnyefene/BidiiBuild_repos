import { put, takeLatest,  all } from 'redux-saga/effects';

    // function* hideAddNewProductForm() {
    //     yield put(
    //         { type: "INVESTMENTS_RECEIVED",
    //             json: json.articles,
    //         }
    //     );
    // }
    //
    // function* actionWatcher() {
    //     yield takeLatest('GET_NEWS', fetchNews, )
    //     yield takeLatest('FETCH_INVESTMENTS', fetchInvestments, )
    // }
    //
    // export default function* rootSaga() {
    //     yield all([
    //         actionWatcher(),
    //     ]);
    // }
