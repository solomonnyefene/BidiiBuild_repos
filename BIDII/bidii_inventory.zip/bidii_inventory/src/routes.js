import React from 'react';
import {Route, indexRoute} from 'react-router';


const Routes = {
    root: '/',
    newp: '/new-product',
    suppliers: '/suppliers',
    projects: '/projects'
};

export default  Routes