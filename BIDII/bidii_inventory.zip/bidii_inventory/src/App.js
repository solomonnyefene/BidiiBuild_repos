import React, { Component } from 'react';
import { connect } from 'react-redux'



//Css
import './general.css'
import 'antd/dist/antd.css';
import './Vendor/css/genicons.css'
import './Vendor/css/dimensions.css'
import './Vendor/css/Bootstrap4.css'
import './Vendor/css/media_queries.css'

 //Components
import NewProduct from './components/NewProduct';
import Projects from './components/Projects/Project'
import Supplier from './components/Suplier/Supplier'
import HeaderTop from './components/Head/Header-top';
import HeaderMiddle from './components/Head/Header-middle';
import HeaderBottom from './components/Head/Header-bottom';

// import NewsItem from '../containers/NewsItem'
// import Loading from '../containers/Loading'
import Button from 'antd/lib/button';

//Actions

import {
    showAddNewProductForm,
    hideAddNewProductForm} from './actions/productActions';

class App extends Component {

    handleShowAddNewProductForm = () => {
        this.props.showAddNewProductForm()
    }
    handleHideAddNewProductForm  = ()=> {
        this.props.hideAddNewProductForm()
    }

    render(){
        let isShowAddNewProduct = this.props.isShowAddNewProduct

        return(
            <div>
                <HeaderTop/>
                <HeaderMiddle/>

                {/*<Supplier/>*/}

                {/*<Projects/>*/}

                {
                    isShowAddNewProduct?
                        <div>
                            <HeaderBottom/>
                            <NewProduct
                                 handleHideAddNewProductForm = {this.handleHideAddNewProductForm}
                            />
                        </div>
                        :
                        <div className="text-right">
                            <Button onClick={this.handleShowAddNewProductForm}  type="primary mt-10 mr-30">
                                New product
                            </Button>

                        </div>
                }

            </div>
        )
    }
}

const mapStateToProps = state => {
    return {
        isShowAddNewProduct: state.product.isShowAddNewProduct
    }
};

const mapDispatchToProps = dispatch => {
    return {
        showAddNewProductForm: () => {dispatch(showAddNewProductForm())},
        hideAddNewProductForm: () => {dispatch(hideAddNewProductForm())},
    }
}


App = connect(mapStateToProps,mapDispatchToProps)(App)
export default App;
