export const getNews = () => ({
    type: 'GET_NEWS',
});
export const fetchInvestments = () => ({
    type: 'FETCH_INVESTMENTS',
});


export default function showAddNewProductForm () {
    return {
        type: 'SHOW_ADD_NEW_PRODUCT_FORM',
    }
}
export default function showAddNewProductForm () {
    return {
        type: 'HIDE_ADD_NEW_PRODUCT_FORM',
    }
}