export const handleCheck = (payload) => ({
    type: 'HANDLE_CHECK',
    payload: payload
});

export const showHiddenSearchBar = (payload) => ({
    type: 'HANDLE_SHOW_HIDDEN_SEARCH_BAR',
    payload: payload
});

