export const showAddNewProductForm = () => ({
    type: 'SHOW_ADD_NEW_PRODUCT_FORM',
});
export const hideAddNewProductForm = () => ({
    type: 'HIDE_ADD_NEW_PRODUCT_FORM',
});