import {combineReducers} from 'redux'
import gen from './gen'
import productReducer from './productReducer'
import supplierReducer from './supplierReducer'

const reducers = combineReducers({
   gen: gen,
   supplier: supplierReducer,
   product: productReducer

});


export default reducers
