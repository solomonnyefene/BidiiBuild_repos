
let Initial_state = {
    products:{},
    isShowAddNewProduct:false,
    isShowHiddenSearchBar:false
}

const supplierReducer = (state =Initial_state , action) => {
    switch (action.type) {
        case 'HANDLE_CHECK':
            return {
                ...state.suppliers,
                isChecked: action.payload,
                isShowHiddenSearchBar: false
            };
        case 'HANDLE_SHOW_HIDDEN_SEARCH_BAR':
        return {
            ...state.supplier,
            isShowHiddenSearchBar: action.payload
        };

        default:
            return state;
    }
}
export default supplierReducer;

