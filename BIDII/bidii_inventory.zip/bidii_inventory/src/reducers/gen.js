
let Initial_state = {
    news:{
        title:'MENZGOLD KILLS BANK OF GHANA',
        author:'Appiah Mensah',
        body:'The CEO of Menzgold, Nana Appiah Mensah has ....',
        url:'www.bankofghana.com'
    },
    loading:false,

}

const gen = (state =Initial_state , action) => {
    switch (action.type) {
        case 'GET_NEWS':
            return {
                ...state,
                loading: true
            };

        case 'NEWS_RECEIVED':
            return {
                ...state,
                news: action.json[0],
                loading: false
            }
        case 'GET_INVESTMENTS':
            return {
                ...state,
                loading: true
            };
        case 'INVESTMENTS_RECEIVED':
            return {
                ...state,
                investments: action.json,
                loading: false
            }
        default:
            return state;
    }
}
export default gen


