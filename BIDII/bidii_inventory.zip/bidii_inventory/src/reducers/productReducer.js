
let Initial_state = {
    products:{},
    isShowAddNewProduct:false
}

const productReducer = (state =Initial_state , action) => {
    switch (action.type) {
        case 'SHOW_ADD_NEW_PRODUCT_FORM':
            return {
                ...state,
                isShowAddNewProduct: true
            };

        case 'HIDE_ADD_NEW_PRODUCT_FORM':
            return {
                ...state,
                isShowAddNewProduct: false
            }

        default:
            return state;
    }
}
export default productReducer;


