import React from 'react';
import { connect } from 'react-redux'
const imgStyle = {
    hight: 'auto',
    width: '80%',
    border: '4px solid RebeccaPurple ',
    borderRadius: '5%'
};
const articleStyle = {
    width: '50%',
    margin: '0 auto',
    color: 'olive'
}
let NewsItem = ({ news }) => (
    news ?
        <article style={articleStyle} >
            <div>
                <h1>{news.title}</h1>
                <img style={imgStyle} src={news.author} alt="" />
                <h4>{news.body}</h4>
                <a href={news.url} target="_blank">READ MORE</a>
            </div>
        </article> :
        null
);
const mapStateToProps = (state) => ({
    news: state.gen.news,
})
NewsItem = connect(mapStateToProps,null)(NewsItem)
export default NewsItem;