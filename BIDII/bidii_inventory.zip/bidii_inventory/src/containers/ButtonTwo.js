import React from 'react';
import { connect } from 'react-redux';
import { fetchInvestments } from '../actions';
let ButtonTwo=({fetchInestments})=>(
    <button onClick={fetchInvestments}>Click to fetch investments</button>
)

const mapDispatchToProps = {
    fetchInvestments: fetchInvestments,
};
ButtonTwo = connect(null,mapDispatchToProps)(ButtonTwo);
export default ButtonTwo;