import React, { Component } from 'react';

//Antd components
import Button from 'antd/lib/button';


class HeaderBottom extends Component {
    render(){
        return(

            <div className="header-bottom col-md-12  text-right">
                <div className="row">
                    <div className="col-6 text-left">
                        <h5 className="f-20">New product/material</h5>
                    </div>
                    <div className="col-6">
                        <div className="inline" style={{marginRight:'15px'}}>
                            <Button  type="primary">
                                Save
                            </Button>
                            <span className="close genicons genicon-cross-cancel"/>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default HeaderBottom
