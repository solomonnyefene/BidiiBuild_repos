import React, { Component } from 'react';

//Components
import Button from 'antd/lib/button';

//Antd modules/components
import {
    Icon,
    Menu,
    Input,
    Dropdown,
    Select
     } from 'antd';

const Search = Input.Search;

let  Option = Select.Option;
    function handleChange(value) {
        alert(`selected ${value}`);
    }

    function handleBlur() {
        console.log('blur');
    }

    function handleFocus() {
        console.log('focus');
    }



let suppliers_filter_menu= (
    <Menu>
        <Menu.Item key="0">
            <span>
                All suppliers
            </span>
        </Menu.Item>
        <Menu.Item key="0">
            <span>
                Active suppliers
            </span>
        </Menu.Item>
        <Menu.Item key="0">
            <span>
                Inactive suppliers
            </span>
        </Menu.Item>
        {/*<Menu.Divider />*/}
        {/*<Menu.Item key="3">3rd menu item</Menu.Item>*/}
    </Menu>
);

let suppliers_sort_menu= (
    <Menu>
        <Menu.Item key="0">
            <span>
                Company name
            </span>
        </Menu.Item>
        <Menu.Item key="0">
            <span>
                Short name
            </span>
        </Menu.Item>
        <Menu.Item key="0">
            <span>
                Email
            </span>
        </Menu.Item>
        <Menu.Item key="0">
            <span>
                Type
            </span>
        </Menu.Item>
        <Menu.Divider />
        <Menu.Item key="0">
            <span>
                Import supplier
            </span>
        </Menu.Item>
        <Menu.Item key="0">
            <span>
                Export supplier
            </span>
        </Menu.Item>
        <Menu.Item key="0">
            <span>
                Refresh list
            </span>
        </Menu.Item>
    </Menu>
);



let SupplierPropertyPane = (props) => {
    let {
        isChecked,
        handleSelectChange,
        isShowHiddenSearchBar,
        handleShowHiddenSearchBar
    } = props
    return(
        <div className="property-pane col-12">
            <div className="d-inline-block">
                {
                    isChecked?
                        <div className="mark_as-select_wrap">
                            <Select defaultValue="Mark as"
                                    // style={{}}
                                    onChange={handleChange}>
                                {/*<Option value="disabled" disabled>Markas</Option>*/}
                                <Option value="jack">
                                    Active
                                </Option>
                                <Option value="lucy">
                                    Inactive
                                </Option>
                            </Select>
                            &nbsp; &nbsp; &nbsp;
                            <Icon  type="delete" />
                        </div>
                        :
                        <Dropdown overlay={suppliers_filter_menu}
                                  trigger={['click']}>
                    <span>
                        All suplliers <Icon type="down" />
                    </span>
                        </Dropdown>

                }

            </div>
            <div className="spp-right d-inline-block ">
                {/*---This search bar display on smaller screen when the search icon is clicked--*/}
                {
                    isShowHiddenSearchBar?
                        <div className="hidden-searchbar-spl">
                            <Search
                                title="Search"
                                placeholder="Search supplier"
                                onSearch={value => console.log(value)}
                                style={{ width: 200 }}/>
                        </div>
                        :''
                }

                {/*--end----*/}

                {
                    isShowHiddenSearchBar === false?
                        <div>
                            <div className="search-icon-wrap">
                                <Icon type="search"
                                      title="Click to search"
                                      onClick={handleShowHiddenSearchBar}/>
                            </div>

                            <div className=" search-bar-spl  mr-20">
                    <span className="ant-input-affix-wrapper search-bar">
                            <span className="ant-input-prefix">
                                <i className="anticon anticon-search search-icon">
                                </i>
                            </span>
                            <Search
                                placeholder="Search supplier"
                                onSearch={value => console.log(value)}
                                style={{ width: 200 }}/>
                    </span>
                            </div>
                            <div className="d-inline-block mr-20">
                                <Button  type="primary">
                                    New supplier
                                </Button>
                            </div>
                            <Dropdown overlay={suppliers_sort_menu}
                                      placement="bottomRight"
                                      trigger={['click']}>
                    <span>
                        <span className="genicons genicon-menu-lines"/>
                        {/*<Icon type="down" />*/}
                    </span>
                            </Dropdown>
                        </div>
                        :''

                }

            </div>
        </div>
    )
}

export default SupplierPropertyPane