import React, { Component } from 'react';

//Antd modules/components


import Button from 'antd/lib/button';

import {
    Icon,
    Menu,
    Input,
    Dropdown,
    Select
} from 'antd';
const Search = Input.Search;

let ProjectPropertyPane = (props) => {

    return(
        <div className="property-pane col-12">
            <div className="row ">
                <div className="col-3">
                    <div className="projects-fiter-div">
                        <small>
                            All projects
                            &nbsp;
                            <span className="anticon anticon-caret-down light"/>
                        </small>
                        <div className="dropdown-content">
                            <p> All projects</p>
                            <p> Behind</p>
                            <p> Completed</p>
                            <p> In progress</p>
                            <p> Ahead</p>
                            <hr/>
                            <p>Created by me</p>
                            <p>Invited to join</p>
                        </div>
                    </div>
                </div>
                <div className="col-6 text-center" >
                        <span className="ant-input-affix-wrapper search-bar">
                            <span className="ant-input-prefix">
                                <i className="anticon anticon-search search-icon">
                                </i>
                            </span>
                            <input placeholder="Search project"
                                   type="text"
                                   className="ant-input"
                                   value=""/>
                        </span>
                </div>
                <div className="col-3 text-right">
                    <div className="view-tgl-btns">
                        <Button title="list view">
                            <span className="genicons genicon-view-list"/>
                        </Button>
                        <Button title="Grid view">
                            <span className="genicons genicon-view-grid"/>
                        </Button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default ProjectPropertyPane