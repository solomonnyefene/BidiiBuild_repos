import React, { Component } from 'react';
import Link from 'react-router-dom/Link'
import Routes from './../../routes'

class HeaderMiddle extends Component {
    render(){
        return(

            <div className="col-12 text-center header-middle">

                <span>
                     <Link  to={Routes.projects}>
                            <span className="navlink">
                                Projects
                            </span>
                        </Link>
                </span>
                <span>
                     <Link  to={Routes.root}>
                            <span className="navlink">
                                NewProduct
                            </span>
                        </Link>
                </span>
                <span>
                    <Link  to={Routes.suppliers}>
                            <span className="navlink">
                                Suppliers
                            </span>
                        </Link>
                </span>

                {/*<span>Nav1</span>*/}
                {/*<span>Nav2</span>*/}
                {/*<span>Nav3</span>*/}
            </div>
        )
    }
}

export default HeaderMiddle
