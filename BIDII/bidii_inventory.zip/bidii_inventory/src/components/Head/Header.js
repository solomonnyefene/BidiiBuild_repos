import React, { Component } from 'react'

/*Header components*/
import HeaderTop from './Header-top'
import HeaderMiddle from './Header-middle'

let Header = (props) => {
    return(
        <div>
            <HeaderTop/>
            <HeaderMiddle/>
        </div>
    )
}

export default Header