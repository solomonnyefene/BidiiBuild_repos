import React, { Component } from 'react';

import logo from './../../Vendor/img/bidiibuiild1.png'

class HeaderTop extends Component {
    render(){
        return(
            <div className="col-12 header-top">
               <div className="row">
                   <div className="col-2 pull-left">
                       <img className="logo" src={logo}/>
                   </div>
                   <div className="col-10 pull-right action-icons-top">
                       <span className=" genicons genicon-view-grid text-white"></span>
                       <span className=" genicons genicon-menu-dots text-white"></span>
                   </div>
               </div>
            </div>
        )
    }
}

export default HeaderTop
