import React, { Component } from 'react';
import { connect } from 'react-redux'

//components
import Button from 'antd/lib/button';
import Header from './../Head/Header'
import SupplierPropertyPane from './../Head/PropertyPanes/supplierProperPane'

//css
import './Supplier.css'

//Antd components
import { Checkbox } from 'antd';

//Actions
import {
    handleCheck,
    showHiddenSearchBar,
    } from './../../actions/supplierActions';

class Supplier extends Component{
    // constructor(props) {
    //     super(props);
    //     this.state = {
    //        isChecked: false
    //     }
    // }


    handleCheckChange = (e)=> {
        let value = e.target.checked,
            payload = value;
        this.props.handleCheck(payload)
    };

    handleShowHiddenSearchBar = ()=> {
        let payload = true;
        this.props.showHiddenSearchBar(payload)
    };

    handleSelectChange = (e)=> {
        let value = e.target.value
        alert(value)
    }

    render(){
        let isChecked = this.props.isChecked,
            isShowHiddenSearchBar = this.props.isShowHiddenSearchBar
        return(
            <div>
                <Header/>
                <SupplierPropertyPane
                    isChecked = {isChecked}
                    isShowHiddenSearchBar ={isShowHiddenSearchBar}
                    handleSelectChange = {this. handleSelectChange}
                    handleShowHiddenSearchBar= {this.handleShowHiddenSearchBar}
                />
                <div className="container-supplier">
                    <div className="table-responsive suppliers-table">
                        <table id="data-table" className="table ">
                            <thead className="s-thead">
                            <tr>
                                <th width="3%">
                                    <div className="ant-checkbox-div">
                                        <Checkbox onChange={this.handleCheckChange}></Checkbox>
                                    </div>
                                </th>
                                <th width="25%">COMPANY NAME</th>
                                <th>OTHER NAME</th>
                                <th>PHONE</th>
                                <th>COUNTRY</th>
                                <th>EMAIL</th>
                                <th>TYPE</th>
                                <th  width="13%" className="text-center">
                                    STATUS
                                    <span className="anticon anticon-setting ml-40 f-20 va-m"
                                          title="Setting"/>
                                </th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <td>
                                    <Checkbox onChange={this.handleCheckChange}></Checkbox>
                                </td>
                                <td>CEMEX LTD</td>
                                <td>CEMEX</td>
                                <td>0549691947</td>
                                <td>GHANA</td>
                                <td>cemex@gmail.com</td>
                                <td>Plumbing</td>
                                <td>
                                    <div className="supplier-status ">
                                        Active
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <Checkbox onChange={this.handleCheckChange}></Checkbox>
                                </td>
                                <td>CEMEX LTD</td>
                                <td>CEMEX</td>
                                <td>0549691947</td>
                                <td>GHANA</td>
                                <td>cemex@gmail.com</td>
                                <td>Plumbing</td>
                                <td>
                                    <div className="supplier-status">
                                        Active
                                    </div>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        )
    }
}


const mapStateToProps = state => {
    return {
         isChecked: state.supplier.isChecked,
         isShowHiddenSearchBar: state.supplier.isShowHiddenSearchBar,
    }
};

const mapDispatchToProps = dispatch => {
    return {
        handleCheck: (payload) => {dispatch(handleCheck(payload))},
        showHiddenSearchBar: (payload) => {dispatch(showHiddenSearchBar(payload))},
    }
}

export default connect(mapStateToProps, mapDispatchToProps)(Supplier)