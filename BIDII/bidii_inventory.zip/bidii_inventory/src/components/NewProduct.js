import React, { Component } from 'react';
import Button from 'antd/lib/button';


import hideAddNewProductForm from './../actions/productActions';

import Header from './Head/Header'

class NewProduct extends Component {
    render(){
        return(
            <div>
                <div className="contain-new-product">
                    <form>
                        <div className="row">
                            <div className="col-md-5 p-form-top" >
                                <div className="row">
                                    <div className="col-4 label-div ">
                                        <small>
                                            Product name
                                        </small>
                                    </div>
                                    <div className="col-8" >
                                        <input placeholder=""
                                               type="text" className="ant-input" />
                                    </div>
                                </div>
                                <br/>
                                <div className="row">
                                    <div className="col-4 label-div">
                                        <small>
                                            Other name
                                        </small>
                                    </div>
                                    <div className="col-8">
                                        <section className="code-box-demo">
                                            <input placeholder=""
                                                   type="text"
                                                   className="ant-input" />
                                        </section>
                                    </div>
                                </div>
                                <br/>
                                <div className="row">
                                    <div className="col-4 label-div">
                                        <small>
                                            Manufacturer
                                        </small>
                                    </div>
                                    <div className="col-8">
                                        <input placeholder=""
                                               type="text"
                                               className="ant-input" />
                                    </div>
                                </div>
                                <br/>
                                <div className="row">
                                    <div className="col-4 label-div">
                                        <small>
                                            UOM
                                        </small>
                                    </div>
                                    <div className="col-8">
                                        <input placeholder=""
                                               type="text"
                                               className="ant-input" />
                                    </div>
                                </div>
                                <br/>
                                <div className="row">
                                    <div className="col-4 label-div">
                                        <small>
                                            Category
                                        </small>
                                    </div>
                                    <div className="col-8">
                                        <input placeholder=""
                                               type="text"
                                               className="ant-input" />
                                    </div>
                                </div>
                            </div>
                            <div className="col-md-7">
                                <div className="row" >
                                    <div className="col-md-7 col-xs-12">
                                        <div className="row wd-100">
                                            <div className="col-5  ">
                                                <small>
                                                    Code
                                                </small>
                                            </div>
                                            <div className="col-7">
                                                <input placeholder=""
                                                       type="text"
                                                       className="ant-input" />
                                            </div>
                                        </div>
                                        <br/>
                                        <div className="row wd-100">
                                            <div className="col-5  ">
                                                <small>
                                                    Code
                                                </small>
                                            </div>
                                            <div className="col-7">
                                                <input placeholder=""
                                                       type="text"
                                                       className="ant-input" />
                                            </div>
                                        </div>
                                        <br/>
                                        <div className="row wd-100">
                                            <div className="col-5  ">
                                                <small>
                                                    Reorder lever
                                                </small>
                                            </div>
                                            <div className="col-7">
                                                <input placeholder=""
                                                       type="text"
                                                       className="ant-input" />
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-md-5 col-xs-12">
                                        <div className="new-product-img-div">
                                    <span tabindex="0" class="ant-upload " role="button">
                                        <input type="file"
                                               accept=""
                                               directory="directory"
                                               webkitdirectory="webkitdirectory"
                                               style={{display: 'none'}}/>
                                            <button type="button" class="ant-btn ml-20">
                                                <i class="anticon anticon-upload"></i>
                                            </button>

                                            <div className="mt-30">
                                                Browse image
                                            </div>
                                    </span>
                                        </div>
                                    </div>
                                </div>
                                <br/>
                                <div className="row">
                                    <div className="col-3">
                                        <small>
                                            Description
                                        </small>
                                    </div>
                                    <div className="col-8  pull-left" style={{paddingRight:'50px'}}>
                                        <input style={{height:'120px', marginLeft:'-20px'}}
                                               placeholder=""
                                               type="textarea"
                                               className="ant-input h-60" />
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="save_council">
                            <Button  type="primary">
                                Save
                            </Button>
                            &nbsp;&nbsp;&nbsp;&nbsp;
                            <Button type="" >
                                Cancel
                            </Button>
                        </div>
                    </form>
                </div>
            </div>
        )
    }
}


export default NewProduct
