import React, { Component } from 'react';

//css
import './Project.css'

//Com[onent
import Header from './../Head/Header'
import ProjectPropertyPane from './../Head/PropertyPanes/projectPropertyPane'

//img
import test from './../../Vendor/img/dynamicImge.jpg'

//Antd components
import {Input} from 'antd';
import Button from 'antd/lib/button';

const Search = Input.Search;


class Projects extends Component {
    render(){
        let hasImg = true

        return(
            <div>
                 <Header/>
                <ProjectPropertyPane/>
                <div className="col-12 body ">
                    <div className="projs-div-wrapper">
                        <div className=" projs-container">
                            <div className="proj-grid">
                                <div className="col-6 text-center content-add-project-div">
                                    <span className="anticon anticon-plus-circle f-48"></span>
                                    <div>
                                        <lagre className="add-project">
                                            Add Project
                                        </lagre>
                                    </div>
                                </div>
                            </div>
                            <div className="proj-grid">
                                <div className="proj-img-container">
                                    <img src={test}/>
                                    <span className="genicons genicon-menu-dots proj-nav-dropdown-icon" >
                                    <div className="proj-nav-dropdown-menu">
                                        <p>
                                            <span className="anticon anticon-setting"/>
                                            &nbsp;
                                            Edit
                                        </p>
                                        <p>
                                             <span className="anticon anticon-appstore-o"/>
                                            &nbsp;
                                            Dashboard
                                        </p>
                                        <p>
                                            <span className="anticon anticon-bars"/>
                                            &nbsp;
                                            Overview
                                        </p>
                                        <p>
                                             <span className="anticon anticon-user"/>
                                            &nbsp;
                                            People
                                        </p>
                                        <p>
                                             <span className="genicons genicon-task-hammer"/>
                                            &nbsp;
                                            Task
                                        </p>
                                        <p>
                                            <span className="anticon anticon-file"/>
                                            &nbsp;
                                            Documents
                                        </p>
                                    </div>
                                </span>
                                    {
                                        hasImg?
                                            <div className="ant-progress-outer proj-prog-bar">
                                                <div className="ant-progress-inner prog-inner">
                                                    <div className="ant-progress-bg pbar"
                                                         style={{width: '30%', height: '12px'}}>
                                                    </div>
                                                </div>
                                            </div>
                                            :''
                                    }

                                </div>
                                <div className="proj-details">
                                    <div className="row">
                                        <div className="col-9 ellipsis proj-name" >
                                            Sandcity New Business Centinghjhghj gjhghj
                                        </div>
                                        <div className="col-3 proj-progress">
                                    <span className="f-20 " >
                                        30%
                                    </span>
                                        </div>
                                    </div>
                                    <div className="row proj-det-bottom">
                                        <div className="col-9 ellipsis ">
                                            <small>
                                                Owner
                                            </small>
                                        </div>
                                        <div className="col-3 ">
                                    <span  >
                                         <small>
                                             Behind
                                         </small>
                                    </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="proj-grid">
                                <div className="proj-img-container">
                                 <span className="genicons genicon-menu-dots proj-nav-dropdown-icon" >
                                    <div className="proj-nav-dropdown-menu">
                                        <p>
                                            <span className="anticon anticon-setting"/>
                                            &nbsp;
                                            Edit
                                        </p>
                                        <p>
                                             <span className="anticon anticon-appstore-o"/>
                                            &nbsp;
                                            Dashboard
                                        </p>
                                        <p>
                                            <span className="anticon anticon-bars"/>
                                            &nbsp;
                                            Overview
                                        </p>
                                        <p>
                                             <span className="anticon anticon-user"/>
                                            &nbsp;
                                            People
                                        </p>
                                        <p>
                                             <span className="genicons genicon-task-hammer"/>
                                            &nbsp;
                                            Task
                                        </p>
                                        <p>
                                            <span className="anticon anticon-file"/>
                                            &nbsp;
                                            Documents
                                        </p>
                                    </div>
                                </span>
                                </div>
                                <div className="proj-details">
                                    <div className="row">
                                        <div className="col-9 ellipsis proj-name" >
                                            DHGate prime unit
                                        </div>
                                        <div className="col-3 proj-progress">
                                    <span className="f-20 " >
                                        70%
                                    </span>
                                        </div>
                                    </div>
                                    <div className="row proj-det-bottom">
                                        <div className="col-9 ellipsis ">
                                            <small>
                                                Owner
                                            </small>
                                        </div>
                                        <div className="col-3 ">
                                    <span  >
                                         <small>
                                             Behind
                                         </small>
                                    </span>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div className="proj-grid">
                                <div className="proj-img-container">
                                 <span className="genicons genicon-menu-dots proj-nav-dropdown-icon" >
                                    <div className="proj-nav-dropdown-menu">
                                        <p>
                                            <span className="anticon anticon-setting"/>
                                            &nbsp;
                                            Edit
                                        </p>
                                        <p>
                                             <span className="anticon anticon-appstore-o"/>
                                            &nbsp;
                                            Dashboard
                                        </p>
                                        <p>
                                            <span className="anticon anticon-bars"/>
                                            &nbsp;
                                            Overview
                                        </p>
                                        <p>
                                             <span className="anticon anticon-user"/>
                                            &nbsp;
                                            People
                                        </p>
                                        <p>
                                             <span className="genicons genicon-task-hammer"/>
                                            &nbsp;
                                            Task
                                        </p>
                                        <p>
                                            <span className="anticon anticon-file"/>
                                            &nbsp;
                                            Documents
                                        </p>
                                    </div>
                                </span>
                                </div>
                                <div className="proj-details">
                                    <div className="row">
                                        <div className="col-9 ellipsis proj-name" >
                                            DHGate prime unit
                                        </div>
                                        <div className="col-3 proj-progress">
                                    <span className="f-20 " >
                                        70%
                                    </span>
                                        </div>
                                    </div>
                                    <div className="row proj-det-bottom">
                                        <div className="col-9 ellipsis ">
                                            <small>
                                                Owner
                                            </small>
                                        </div>
                                        <div className="col-3 ">
                                    <span  >
                                         <small>
                                             Behind
                                         </small>
                                    </span>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div className="proj-grid">
                                <div className="proj-img-container">
                                 <span className="genicons genicon-menu-dots proj-nav-dropdown-icon" >
                                    <div className="proj-nav-dropdown-menu">
                                        <p>
                                            <span className="anticon anticon-setting"/>
                                            &nbsp;
                                            Edit
                                        </p>
                                        <p>
                                             <span className="anticon anticon-appstore-o"/>
                                            &nbsp;
                                            Dashboard
                                        </p>
                                        <p>
                                            <span className="anticon anticon-bars"/>
                                            &nbsp;
                                            Overview
                                        </p>
                                        <p>
                                             <span className="anticon anticon-user"/>
                                            &nbsp;
                                            People
                                        </p>
                                        <p>
                                             <span className="genicons genicon-task-hammer"/>
                                            &nbsp;
                                            Task
                                        </p>
                                        <p>
                                            <span className="anticon anticon-file"/>
                                            &nbsp;
                                            Documents
                                        </p>
                                    </div>
                                </span>
                                </div>
                                <div className="proj-details">
                                    <div className="row">
                                        <div className="col-9 ellipsis proj-name" >
                                            DHGate prime unit
                                        </div>
                                        <div className="col-3 proj-progress">
                                    <span className="f-20 " >
                                        70%
                                    </span>
                                        </div>
                                    </div>
                                    <div className="row proj-det-bottom">
                                        <div className="col-9 ellipsis ">
                                            <small>
                                                Owner
                                            </small>
                                        </div>
                                        <div className="col-3 ">
                                    <span  >
                                         <small>
                                             Behind
                                         </small>
                                    </span>
                                        </div>
                                    </div>

                                </div>
                            </div>
                            <div className="proj-grid">
                                <div className="proj-img-container">
                                 <span className="genicons genicon-menu-dots proj-nav-dropdown-icon" >
                                    <div className="proj-nav-dropdown-menu">
                                        <p>
                                            <span className="anticon anticon-setting"/>
                                            &nbsp;
                                            Edit
                                        </p>
                                        <p>
                                             <span className="anticon anticon-appstore-o"/>
                                            &nbsp;
                                            Dashboard
                                        </p>
                                        <p>
                                            <span className="anticon anticon-bars"/>
                                            &nbsp;
                                            Overview
                                        </p>
                                        <p>
                                             <span className="anticon anticon-user"/>
                                            &nbsp;
                                            People
                                        </p>
                                        <p>
                                             <span className="genicons genicon-task-hammer"/>
                                            &nbsp;
                                            Task
                                        </p>
                                        <p>
                                            <span className="anticon anticon-file"/>
                                            &nbsp;
                                            Documents
                                        </p>
                                    </div>
                                </span>
                                </div>
                                <div className="proj-details">
                                    <div className="row">
                                        <div className="col-9 ellipsis proj-name" >
                                            DHGate prime unit
                                        </div>
                                        <div className="col-3 proj-progress">
                                    <span className="f-20 " >
                                        70%
                                    </span>
                                        </div>
                                    </div>
                                    <div className="row proj-det-bottom">
                                        <div className="col-9 ellipsis ">
                                            <small>
                                                Owner
                                            </small>
                                        </div>
                                        <div className="col-3 ">
                                    <span  >
                                         <small>
                                             Behind
                                         </small>
                                    </span>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default Projects
