import React from 'react';
import BrowserRouter from 'react-router-dom/es/BrowserRouter'
import Route from 'react-router-dom/es/Route';
import Switch from 'react-router-dom/es/Switch';
import { render } from 'react-dom';
import { Provider } from 'react-redux';
import {store} from './store'


//Components
import Routes from './routes'
import App from './App'
import Supplier from './components/Suplier/Supplier'
import Projects from './components/Projects/Project'
import NewProduct from './components/NewProduct'


render(
    <Provider store={store}>
        <BrowserRouter>
            <Switch>
                <Route exact path={Routes.root} component={App} />
                <Route path={Routes.projects}     component={Projects} />
                <Route path={Routes.newp}     component={NewProduct} />
                <Route path={Routes.suppliers}     component={Supplier} />



                {/*<Switch>*/}
                    {/*<Route exact path={Routes.root} component={Header} />*/}
                    {/*<Route exact path={Routes.login} component={Header} />*/}
                    {/*<Route exact path={Routes.signUp} component={Header} />*/}
                    {/*<Route exact path={Routes.dashboard} component={Header} />*/}
                {/*</Switch>*/}

            </Switch>
        </BrowserRouter>
    </Provider>,
    document.getElementById('root'),
);